# Kamya Sahoo | Portfolio

Static portfolio website (HTML, CSS, JavaScript). No build step.

## Publish with GitHub Pages
1. Create a new GitHub repo, e.g. `kamya-portfolio` (or `<username>.github.io` for a root URL).
2. In this folder run:
   ```
   git init
   git add .
   git commit -m "Add portfolio website"
   git branch -M main
   git remote add origin https://github.com/<username>/kamya-portfolio.git
   git push -u origin main
   ```
3. On GitHub: Settings > Pages > Source: `Deploy from a branch` > Branch `main` / `(root)` > Save.
4. Your site will be live at `https://<username>.github.io/kamya-portfolio/` in a minute or two.

## Edit
Replace the email, LinkedIn and GitHub links in the Contact section of `index.html`.
